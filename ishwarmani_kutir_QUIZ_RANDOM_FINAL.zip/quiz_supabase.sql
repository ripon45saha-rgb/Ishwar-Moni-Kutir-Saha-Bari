-- ঈশ্বরমনি কুঠির — Quiz database setup
create table if not exists public.quiz_results (
  id bigint generated always as identity primary key,
  name text not null,
  phone text not null unique,
  score integer not null default 0 check (score between 0 and 10),
  correct integer not null default 0 check (correct between 0 and 10),
  wrong integer not null default 0 check (wrong between 0 and 10),
  timed_out integer not null default 0 check (timed_out between 0 and 10),
  answers jsonb,
  created_at timestamptz default now()
);

alter table public.quiz_results enable row level security;

drop policy if exists "Anyone can submit quiz result" on public.quiz_results;
create policy "Anyone can submit quiz result"
on public.quiz_results
for insert to anon, authenticated
with check (true);

drop policy if exists "Authenticated admins can view quiz results" on public.quiz_results;
create policy "Authenticated admins can view quiz results"
on public.quiz_results
for select to authenticated
using (true);
